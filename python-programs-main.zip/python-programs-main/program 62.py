'''program to print th coloured text in the terminal'''

from termcolor import colored
print(colored("This is easycodingzone",'red'))



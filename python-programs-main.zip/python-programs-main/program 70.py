'''progarm to count the occurance of a element in the list'''

mylist=[1,2,3,4,2,4,2,4,2,2,2,2,2,2,4,5,6,76]
print(mylist.count(2))
